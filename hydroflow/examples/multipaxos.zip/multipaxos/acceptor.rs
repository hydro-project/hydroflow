use crate::protocol::{ProposerMsg, MsgType, AcceptorResponse};
use crate::Opts;
use hydroflow::builder::prelude::*;
use hydroflow::scheduled::handoff::VecHandoff;

use rand::Rng;
fn decide(odds: u8) -> bool {
    let mut rng = rand::thread_rng();
    if rng.gen_range(0..100) > odds {
        return false;
    } else {
        return true;
    };
}

fn create_handoff<T>(hf: Hydroflow, name: String) -> VecHandoff<T> {
    let (p1a_recv_push, p1a_recv_pull) =
        hf.make_edge::<_, VecHandoff<T>, _>(name);
}

pub(crate) async fn run_acceptor(opts: Opts, coordinator: String) {
    let mut hf = HydroflowBuilder::default();

    // Setup message send/recv ports
    let msg_recv = hf
        .hydroflow
        .inbound_tcp_vertex_port::<ProposerMsg>(opts.port)
        .await;
    let msg_recv = hf.wrap_input(msg_recv);
    let msg_send = hf.hydroflow.outbound_tcp_vertex::<AcceptorResponse>().await;
    let msg_send = hf.wrap_output(msg_send);


    hf.add_subgraph_stratified(
        "demux",
        0,
        msg_recv.flatten().pull_to_push().partition(
            |m| m.mtype == MsgType::P1A,
            hf.start_tee().map(Some).push_to(),
            hf.start_tee().map(Some).push_to(),
        )
    )
    
    let mut hf = hf.build();
    println!("Opening on port {}", opts.port);
    hf.run_async().await.unwrap();
}
