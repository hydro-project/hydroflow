This is a detailed diagram of the dataflow for acceptor logic.

```mermaid
graph TD;
    subgraph routing
        proposer --> p1v2_tee
        p1v2_tee --> p1a_push
        p1v2_tee --> p2a_push
        p1a_push --> p1a_pull
        p2a_push --> p2a_pull
    end
    subgraph phase1
        p1a_pull --> proposer
        
    end
```

Below is a high level sketch of the way p2a should work.
```mermaid
graph TD
    X( ) -->|proposer| A(p2a)
    A(p2a) --> B(ballots)
    B(ballots) -->|new_stratum| D(max_ballot)
    A(p2a) --> C(log)
    C(log) --> C(log)
    A(p2a) --> E(p2b)
    D(max_ballot) --> E(p2b)
    D(max_ballot) --> C(log)
```